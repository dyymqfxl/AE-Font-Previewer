[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('11', '12')]
    [string[]]$CepVersion = @('11', '12')
)

$ErrorActionPreference = 'Stop'
foreach ($version in $CepVersion) {
    $path = "Software\Adobe\CSXS.$version"
    if ($PSCmdlet.ShouldProcess("HKCU\$path", 'Set PlayerDebugMode (REG_SZ) to 1')) {
        $key = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey($path)
        try {
            $key.SetValue('PlayerDebugMode', '1', [Microsoft.Win32.RegistryValueKind]::String)
            Write-Host "Enabled CEP $version debug mode for the current user."
        } finally {
            $key.Dispose()
        }
    }
}
