/* global cep_node, __adobe_cep */
'use strict';
const defaultSample = 'Aa 123';
const $ = Object.fromEntries(Array.from(document.querySelectorAll('[id]'), el => [el.id, el]));
let fonts = [], families = [], visible = [], selected = null, busy = false, applying = false, next = null;
let settings = {favorites: [], sample: '', size: 14, wheel: 3, live: false};
let rowHeight = 23, paintFrame = 0, favoritesOnly = false;
let visibleFamilies = 0;
const expandedFamilies = new Set();
const installedFaces = new Map();

function save() {
  try { localStorage.setItem('font-browser-v1', JSON.stringify(settings)); }
  catch (_) {}
}

try {
  const saved = JSON.parse(localStorage.getItem('font-browser-v1'));
  if (saved && Array.isArray(saved.favorites)) {
    settings = Object.assign(settings, saved);
  }
} catch (_) {}

function familyKey(font) {
  return 'family:' + font.family;
}

function filter(resetScroll) {
  const favorites = new Set(settings.favorites);
  const shown = favoritesOnly ? families.filter(f => favorites.has(familyKey(f))) : families;
  visibleFamilies = shown.length;
  const characters = [...new Set(Array.from($.sample.value.normalize('NFC'))
    .filter(char => !/[\s\p{Cc}\p{Cf}\uFE00-\uFE0F\u{E0100}-\u{E01EF}]/u.test(char))
    .map(char => char.codePointAt(0)))];
  const supportsAll = font => characters.length === 0 ||
    (font.supports && characters.every(code => font.supports(code)));
  const matching = [], remaining = [];
  for (const family of shown) {
    const supported = supportsAll(family);
    const styles = family.variants;
    const matchingStyles = styles && styles.filter(supportsAll);
    const preview = supported ? family : matchingStyles && matchingStyles[0];
    const rows = [{...family, preview, missingGlyphs: !preview}];
    if (styles && expandedFamilies.has(family.family)) {
      const ordered = matchingStyles.concat(styles.filter(style => !matchingStyles.includes(style)));
      for (const style of ordered) {
        rows.push({...style, child: true, missingGlyphs: !matchingStyles.includes(style)});
      }
    }
    (preview ? matching : remaining).push(...rows);
  }
  visible = matching.concat(remaining);
  selected = visible.find(f => selected && f.ps === selected.ps && f.child === selected.child)
    || visible.find(f => selected && f.family === selected.family) || visible[0] || null;
  if (resetScroll) $.list.scrollTop = 0;
  paint();
}

function toggleFamily(f) {
  if (expandedFamilies.has(f.family)) expandedFamilies.delete(f.family);
  else expandedFamilies.add(f.family);
  selected = f;
  filter(false);
}

function cssString(s) { return '"' + s.replace(/["\\]/g, '\\$&').replace(/[\r\n\f]/g, ' ') + '"'; }
function face(f) {
  if (installedFaces.has(f.ps)) return installedFaces.get(f.ps);
  const key = 'fb-' + installedFaces.size;
  // Exact face names keep Bold, Italic, and condensed variants distinct.
  const sources = [...new Set([f.ps, f.full].filter(Boolean))].map(n => 'local(' + cssString(n) + ')');
  if (f.url) sources.push('url(' + cssString(f.url) + ')');
  const src = sources.join(',');
  const font = new FontFace(key, src);
  document.fonts.add(font);
  font.load().catch(() => {});
  installedFaces.set(f.ps, key);
  return key;
}
function drawSample(el, f) {
  el.textContent = $.sample.value || defaultSample;
  el.style.fontFamily = face(f) + ', "Microsoft YaHei UI", sans-serif';
}
function rowForFont(ps) {
  const exact = visible.find(f => f.ps === ps && !f.variants);
  if (exact) return exact;
  const font = fonts.find(f => f.ps === ps);
  return font && visible.find(f => !f.child && f.family === font.family);
}

function paint() {
  if (paintFrame) cancelAnimationFrame(paintFrame);
  paintFrame = 0;
  $.countNumber.textContent = visibleFamilies + '/' + families.length;
  $.count.title = $.countNumber.textContent + ' 个字体';
  $.rows.style.height = (visible.length * rowHeight) + 'px';
  document.documentElement.style.setProperty('--list-scrollbar', ($.list.offsetWidth - $.list.clientWidth) + 'px');
  const start = Math.max(0, Math.floor($.list.scrollTop / rowHeight) - 2);
  const end = Math.min(visible.length, start + Math.ceil($.list.clientHeight / rowHeight) + 5);
  const rows = document.createDocumentFragment();
  for (let i = start; i < end; i++) {
    const f = visible[i], row = document.createElement('div');
    row.className = 'row' + (f === selected ? ' selected' : '') +
      (f.child ? ' child' : '') +
      (f.missingGlyphs ? ' missing-glyphs' : '');
    row.dataset.index = i;
    row.style.top = i * rowHeight + 'px';
    const name = document.createElement(f.variants ? 'button' : 'div');
    const sample = document.createElement('div');
    name.className = 'name';
    sample.className = 'sample';
    if (f.variants) {
      name.type = 'button';
      name.classList.add('family-name');
      name.setAttribute('aria-expanded', expandedFamilies.has(f.family));
    }
    const star = document.createElement(f.child ? 'span' : 'button');
    if (!f.child) {
      const liked = settings.favorites.includes(familyKey(f));
      star.type = 'button';
      star.className = 'star';
      star.textContent = liked ? '★' : '☆';
      star.setAttribute('aria-pressed', liked);
      star.setAttribute('aria-label', (liked ? '取消收藏' : '收藏') + f.family);
    }
    name.textContent = f.child ? f.style : f.family;
    row.title = f.child ? f.family + ' · ' + f.style : f.family;
    drawSample(sample, f.preview || f);
    row.append(star, name, sample);
    rows.append(row);
  }
  $.rows.replaceChildren(rows);
}

function reveal(f) {
  const top = visible.indexOf(f) * rowHeight;
  if (top < $.list.scrollTop) $.list.scrollTop = top;
  if (top + rowHeight > $.list.scrollTop + $.list.clientHeight) $.list.scrollTop = top + rowHeight - $.list.clientHeight;
}

function choose(f, scroll) {
  if (!f) return;
  selected = f;
  if (scroll) reveal(f);
  // Keep the clicked node mounted until a second click can become a double-click.
  $.rows.querySelectorAll('.row').forEach(row => row.classList.toggle('selected', visible[Number(row.dataset.index)] === selected));
  if ($.live.checked) apply(f);
}
function host(script) {
  return new Promise(resolve => {
    if (!window.__adobe_cep__) return resolve({ok:false});
    window.__adobe_cep__.evalScript(script, raw => {
      try { resolve(JSON.parse(raw)); }
      catch (_) { resolve({ok:false}); }
    });
  }).catch(() => ({ok:false}));
}
async function apply(f) {
  if (!f || f.variants) return;
  if (applying) { next = f; return; }
  applying = true;
  const arg = JSON.stringify(f.ps).replace(/[\u2028\u2029]/g, c => '\\u' + c.charCodeAt(0).toString(16));
  await host('AEFontBrowser.apply(' + arg + ')');
  applying = false;
  const pending = next;
  next = null;
  if (pending && pending.ps !== f.ps) apply(pending);
}

async function scan() {
  if (busy) return;
  busy = $.refresh.disabled = true;
  try {
    const req = window.cep_node ? cep_node.require : require;
    const extensionPath = req('url').fileURLToPath(new URL('.', location.href).href);
    const reader = req(req('path').join(extensionPath, 'font-reader.js'));
    const result = await reader.scan();
    fonts = result.fonts;
    const byFamily = new Map();
    for (const font of fonts) {
      if (!byFamily.has(font.family)) byFamily.set(font.family, []);
      byFamily.get(font.family).push(font);
    }
    families = [...byFamily.values()].map(styles => {
      if (styles.length === 1) return styles[0];
      const preview = styles.find(f => /^(regular|normal|常规)$/i.test(f.style)) || styles[0];
      return {...preview, variants: styles};
    });
    // Move old per-style favorites to families as their fonts become available.
    const oldKeys = new Map(fonts.map(f => [f.ps, familyKey(f)]));
    const favorites = [...new Set(settings.favorites.map(key => oldKeys.get(key) || key))];
    if (favorites.length !== settings.favorites.length || favorites.some((key, i) => key !== settings.favorites[i])) {
      settings.favorites = favorites;
      save();
    }
  } catch (_) {
  } finally {
    busy = $.refresh.disabled = false;
    filter(true);
  }
}
function rowFrom(e) {
  const row = e.target.closest('.row');
  return row ? visible[Number(row.dataset.index)] : null;
}

$.list.addEventListener('scroll', () => { if (!paintFrame) paintFrame = requestAnimationFrame(paint); });
$.list.addEventListener('wheel', e => {
  if (!e.deltaY || e.ctrlKey) return;
  e.preventDefault();
  const steps = e.deltaMode ? Math.min(3, Math.abs(e.deltaY)) : Math.max(1, Math.min(5, Math.round(Math.abs(e.deltaY) / 100)));
  $.list.scrollTop += Math.sign(e.deltaY) * steps * rowHeight * Number($.wheel.value);
}, {passive:false});
$.list.addEventListener('click', e => {
  const f = rowFrom(e);
  if (!f) return;
  if (e.target.closest('.star')) {
    const key = familyKey(f);
    if (settings.favorites.includes(key)) settings.favorites = settings.favorites.filter(favorite => favorite !== key);
    else settings.favorites.push(key);
    save();
    filter(false);
  } else {
    $.list.focus({preventScroll:true});
    if (f.variants) {
      if (e.detail < 2) toggleFamily(f);
    } else if (f !== selected || ($.live.checked && e.detail === 1)) choose(f, false);
  }
});
$.list.addEventListener('dblclick', e => { if (!e.target.closest('.star') && !$.live.checked) apply(rowFrom(e)); });
$.list.addEventListener('keydown', e => {
  if (e.target !== $.list) return;
  const steps = {ArrowUp:-1, ArrowDown:1, PageUp:-Math.max(1, Math.floor($.list.clientHeight / rowHeight)), PageDown:Math.max(1, Math.floor($.list.clientHeight / rowHeight))};
  if (Object.prototype.hasOwnProperty.call(steps, e.key)) {
    e.preventDefault();
    choose(visible[Math.min(visible.length - 1, Math.max(0, visible.indexOf(selected) + steps[e.key]))], true);
  } else if (e.key === 'Enter') {
    e.preventDefault();
    if (selected && selected.variants) toggleFamily(selected);
    else apply(selected);
  }
});

$.favoritesOnly.onclick = () => {
  favoritesOnly = !favoritesOnly;
  $.favoritesOnly.setAttribute('aria-pressed', favoritesOnly);
  $.favoritesOnly.textContent = favoritesOnly ? '★' : '☆';
  $.favoritesOnly.title = favoritesOnly ? '显示全部字体' : '只看收藏';
  filter(true);
};
function updateSample() {
  settings.sample = $.sample.value;
  $.clearSample.disabled = !settings.sample;
  save();
  filter(true);
}
$.sample.oninput = updateSample;
$.clearSample.onclick = () => {
  $.sample.value = '';
  updateSample();
  $.sample.focus();
};
$.read.onclick = async () => {
  // Query AE only on demand so native text editing can keep focus.
  const r = await host('AEFontBrowser.read()');
  if (!r || !r.ok) return;
  $.sample.value = r.text;
  updateSample();
  const row = rowForFont(r.font);
  if (row) {
    // Reading a layer never writes back, even with live application enabled.
    selected = row;
    reveal(row);
    paint();
  }
};
function sizeChanged() {
  const size = Number($.size.value) || 14;
  rowHeight = Math.max(22, size + 9);
  document.documentElement.style.setProperty('--row', rowHeight + 'px');
  document.documentElement.style.setProperty('--sample', size + 'px');
  settings.size = size;
  paint();
}
$.size.onchange = () => { sizeChanged(); save(); };
$.wheel.onchange = () => { settings.wheel = Number($.wheel.value); save(); };
$.live.onchange = () => { settings.live = $.live.checked; save(); };
$.refresh.onclick = scan;

$.sample.value = settings.sample;
$.clearSample.disabled = !$.sample.value;
$.size.value = [12, 14, 16].includes(Number(settings.size)) ? settings.size : 14;
$.wheel.value = settings.wheel;
$.live.checked = settings.live === true;
sizeChanged();
scan();
window.addEventListener('resize', paint);

