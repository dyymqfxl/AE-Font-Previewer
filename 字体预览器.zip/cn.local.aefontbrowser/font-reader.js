'use strict';
// Read the OpenType name table, including every face in TTC collections.
var fs = require('fs'), path = require('path');
function decode(b, unicode) {
  if (!unicode) return b.toString('latin1').replace(/\0/g, '');
  var out = ''; for (var i = 0; i + 1 < b.length; i += 2) out += String.fromCharCode(b.readUInt16BE(i));
  return out.replace(/\0/g, '');
}

function glyphLookup(table, format) {
  if (format === 4 && table.length >= 16) {
    const count = table.readUInt16BE(6) / 2;
    if (!Number.isInteger(count) || !count || 16 + count * 8 > table.length) return;
    const startCodes = 16 + count * 2;
    const deltas = startCodes + count * 2;
    const offsets = deltas + count * 2;
    return code => {
      if (code > 0xffff) return false;
      let lo = 0, hi = count;
      while (lo < hi) {
        const mid = (lo + hi) >>> 1;
        if (table.readUInt16BE(14 + mid * 2) < code) lo = mid + 1;
        else hi = mid;
      }
      if (lo === count) return false;
      const start = table.readUInt16BE(startCodes + lo * 2);
      if (code < start) return false;
      const delta = table.readUInt16BE(deltas + lo * 2);
      const offsetWord = offsets + lo * 2;
      const offset = table.readUInt16BE(offsetWord);
      if (!offset) return ((code + delta) & 0xffff) !== 0;
      const index = offsetWord + offset + (code - start) * 2;
      if (index + 2 > table.length) return false;
      const glyph = table.readUInt16BE(index);
      return glyph !== 0 && ((glyph + delta) & 0xffff) !== 0;
    };
  }
  if ((format === 12 || format === 13) && table.length >= 16) {
    const count = table.readUInt32BE(12);
    if (16 + count * 12 > table.length) return;
    return code => {
      let lo = 0, hi = count - 1;
      while (lo <= hi) {
        const mid = (lo + hi) >>> 1;
        const record = 16 + mid * 12;
        const start = table.readUInt32BE(record);
        if (code < start) hi = mid - 1;
        else if (code > table.readUInt32BE(record + 4)) lo = mid + 1;
        else return table.readUInt32BE(record + 8) + (format === 12 ? code - start : 0) !== 0;
      }
      return false;
    };
  }
}

function readCoverage(cmap) {
  if (cmap.length < 4) return;
  const count = cmap.readUInt16BE(2);
  const checked = new Set(), lookups = [];
  for (let i = 0; i < count && 4 + (i + 1) * 8 <= cmap.length; i++) {
    const record = 4 + i * 8;
    const platform = cmap.readUInt16BE(record), encoding = cmap.readUInt16BE(record + 2);
    if (platform !== 0 && !(platform === 3 && (encoding === 1 || encoding === 10))) continue;
    const offset = cmap.readUInt32BE(record + 4);
    if (checked.has(offset) || offset + 4 > cmap.length) continue;
    checked.add(offset);
    const format = cmap.readUInt16BE(offset);
    const extended = format === 12 || format === 13;
    if (format !== 4 && !extended) continue;
    if (extended && offset + 8 > cmap.length) continue;
    const length = extended ? cmap.readUInt32BE(offset + 4) : cmap.readUInt16BE(offset + 2);
    if (offset + length > cmap.length) continue;
    const lookup = glyphLookup(cmap.subarray(offset, offset + length), format);
    if (lookup) lookups.push(lookup);
  }
  if (lookups.length) return code => lookups.some(lookup => lookup(code));
}

function parse(b) {
  function range(o, n) { if (o < 0 || n < 0 || o + n > b.length) throw Error('Invalid font bounds'); }
  range(0, 12);
  var offsets = [0], results = [];
  const coverageByOffset = new Map();
  if (b.toString('ascii', 0, 4) === 'ttcf') {
    var count = b.readUInt32BE(8); if (count > 1024) throw Error('Invalid TTC');
    range(12, count * 4); offsets = [];
    for (var t = 0; t < count; t++) offsets.push(b.readUInt32BE(12 + t * 4));
  }
  offsets.forEach(function (offset) {
    range(offset, 12); var tables = b.readUInt16BE(offset + 4); range(offset + 12, tables * 16);
    let supports;
    for (let i = 0; i < tables; i++) {
      const entry = offset + 12 + i * 16;
      if (b.toString('ascii', entry, entry + 4) !== 'cmap') continue;
      const start = b.readUInt32BE(entry + 8), length = b.readUInt32BE(entry + 12);
      if (start + length <= b.length) {
        // Copy just the character map so a lookup doesn't retain the whole font file.
        if (!coverageByOffset.has(start)) {
          coverageByOffset.set(start, readCoverage(Buffer.from(b.subarray(start, start + length))));
        }
        supports = coverageByOffset.get(start);
      }
      break;
    }
    for (var j = 0; j < tables; j++) {
      var p = offset + 12 + j * 16;
      if (b.toString('ascii', p, p + 4) !== 'name') continue;
      var base = b.readUInt32BE(p + 8); range(base, 6);
      var n = b.readUInt16BE(base + 2), start = base + b.readUInt16BE(base + 4);
      range(base + 6, n * 12); var names = {}, scores = {}, aliases = [];
      for (var k = 0; k < n; k++) {
        var r = base + 6 + k * 12, platform = b.readUInt16BE(r), lang = b.readUInt16BE(r + 4), id = b.readUInt16BE(r + 6);
        if ([1, 2, 4, 6, 16, 17].indexOf(id) < 0 || [0, 1, 3].indexOf(platform) < 0) continue;
        var length = b.readUInt16BE(r + 8), pos = start + b.readUInt16BE(r + 10); range(pos, length);
        // Mac legacy non-Roman names need a codec; use Unicode records instead.
        if (platform === 1 && b.readUInt16BE(r + 2) !== 0) continue;
        var s = decode(b.slice(pos, pos + length), platform !== 1).trim(); if (!s) continue;
        if ([1, 4, 6, 16].indexOf(id) >= 0 && aliases.indexOf(s) < 0) aliases.push(s);
        var score = (platform === 3 ? 10 : platform === 0 ? 8 : 0) + (lang === 2052 ? 5 : lang === 1033 ? 3 : 0);
        // PostScript identifiers should prefer the invariant, ASCII form when present.
        if (id === 6 && /^[!-~]+$/.test(s)) score += 20;
        if (scores[id] === undefined || score > scores[id]) { names[id] = s; scores[id] = score; }
      }
      if (names[6] && (names[16] || names[1])) results.push({ps: names[6], family: names[16] || names[1], style: names[17] || names[2] || 'Regular', full: names[4] || names[1], aliases: aliases, supports});
      break;
    }
  });
  return results;
}
async function scan(onProgress) {
  var roots = [path.join(process.env.WINDIR || 'C:\\Windows', 'Fonts'), path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Windows', 'Fonts')];
  // Registry entries include fonts installed in nonstandard locations.
  var cp = require('child_process');
  var script = "[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); $ErrorActionPreference='Stop'; $p=@('HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts','HKCU:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts'); $v=@(); foreach($k in $p){if(Test-Path -LiteralPath $k){$key=Get-Item -LiteralPath $k; foreach($n in $key.GetValueNames()){$s=$key.GetValue($n);if($s -is [string]){$v+=$s}}}}; ConvertTo-Json -InputObject @($v) -Compress";
  var extra = await new Promise(function(resolve) {
    cp.execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], {windowsHide: true, maxBuffer: 4*1024*1024}, function(err, stdout) {
      try { resolve(err ? [] : JSON.parse(stdout.replace(/^\uFEFF/, ''))); } catch (_) { resolve([]); }
    });
  }).catch(function() { return []; });
  var files = Object.create(null), found = Object.create(null), skipped = 0;
  roots.forEach(function(root) { try { fs.readdirSync(root).forEach(function(f) {files[path.join(root, f)] = true;}); } catch (_) {} });
  extra.forEach(function(f) { if(path.isAbsolute(f)) files[f] = true; });
  var list = Object.keys(files).filter(function(f) {return /\.(ttf|otf|ttc|otc)$/i.test(f);});
  for (var i = 0; i < list.length; i++) {
    try {
      parse(await fs.promises.readFile(list[i])).forEach(function(f) {
        if (found[f.ps]) return;
        if (/\.(otf|ttf)$/i.test(list[i])) f.url = require('url').pathToFileURL(list[i]).href;
        found[f.ps] = f;
      });
    } catch (_) { skipped++; }
    if (i % 25 === 0 && onProgress) onProgress(i, list.length);
  }
  return {fonts: Object.keys(found).map(function(k) {return found[k];}).sort(function(a,b) {return (a.family+' '+a.style).localeCompare(b.family+' '+b.style, 'zh-CN');}), skipped: skipped};
}
module.exports = {parse: parse, scan: scan};
