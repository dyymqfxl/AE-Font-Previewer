var AEFontBrowser = (function () {
    function esc(s) {
        return '"' + String(s).replace(/["\\\x00-\x1f]/g, function (c) {
            return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
        }) + '"';
    }
    function reply(ok, message) { return '{"ok":' + (ok ? 'true' : 'false') + ',"message":' + esc(message) + '}'; }
    function selected() {
        var c = app.project.activeItem;
        if (!(c instanceof CompItem)) throw Error('请先打开合成并选中文字图层。');
        var out = [], layers = c.selectedLayers;
        for (var i = 0; i < layers.length; i++) {
            var p = layers[i].property('ADBE Text Properties');
            if (p && !layers[i].locked) out.push({layer:layers[i], prop:p.property('ADBE Text Document'), time:c.time});
        }
        if (!out.length) throw Error('请选中至少一个未锁定的文字图层。');
        return out;
    }
    return {
        currentFont: function () {
            try {
                var c = app.project.activeItem;
                if (c instanceof CompItem) {
                    var layers = c.selectedLayers;
                    for (var i = 0; i < layers.length; i++) {
                        var layer = layers[i];
                        var text = layer.property('ADBE Text Properties');
                        if (!text) continue;
                        var font = text.property('ADBE Text Document').valueAtTime(c.time, false).font;
                        var key = c.id + ':' + (layer.id || layer.index);
                        return '{"layer":' + esc(key) + ',"font":' + esc(font) + '}';
                    }
                }
            } catch (_) {}
            return 'null';
        },
        read: function () {
            try { var s = selected()[0], d = s.prop.valueAtTime(s.time, false); return '{"ok":true,"text":' + esc(d.text) + ',"font":' + esc(d.font) + '}'; }
            catch (e) { return reply(false, e.toString()); }
        },
        apply: function (font) {
            var begun = false;
            try {
                if (!font || font.length > 512) throw Error('字体标识无效。');
                var list = selected(), skipped = 0, changed = 0, substituted = 0;
                app.beginUndoGroup('字体预览器：应用字体'); begun = true;
                for (var i = 0; i < list.length; i++) {
                    var s = list[i], p = s.prop;
                    // Animated or expression-driven source text is intentionally protected.
                    if (p.numKeys > 0 || p.expressionEnabled) { skipped++; continue; }
                    var d = p.value; d.font = font; p.setValue(d); changed++;
                    if (p.value.font !== font) substituted++;
                }
                return reply(changed > 0 && substituted === 0, '已应用到 ' + changed + ' 个文字图层。' + (skipped ? ' 跳过 '+skipped+' 个带源文本关键帧/表达式的图层。' : '') + (substituted ? ' AE 替换了字体，请检查字体是否已被 AE 识别；可撤销。' : ' 可用 Ctrl+Z 撤销。'));
            } catch (e) { return reply(false, e.toString() + ' 如已部分应用，可用 Ctrl+Z 撤销。'); }
            finally { if (begun) app.endUndoGroup(); }
        }
    };
}());
